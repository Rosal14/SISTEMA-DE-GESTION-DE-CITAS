const { contextBridge } = require('electron');
const BASE_URL = 'http://localhost:3000/api';
async function apiRequest(endpoint, options = {}) {
  try {
    const response = await fetch(`${BASE_URL}${endpoint}`, {
      headers: {
        'Content-Type': 'application/json',
        ...(options.headers || {})
      },
      ...options
    });
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.message || `Error ${response.status}`);
    }
    if (response.status === 204 || response.status === 200 && !response.headers.get('content-type')?.includes('application/json')) {
      return null;
    }
    return await response.json();
  } catch (error) {
    console.error('API ERROR:', error);
    throw error;
  }
}
contextBridge.exposeInMainWorld('clinicApp', {
  getPacientes: () => apiRequest('/pacientes'),
  getPacienteById: (id) => apiRequest(`/pacientes/${id}`),
  createPaciente: (data) => apiRequest('/pacientes', { method: 'POST', body: JSON.stringify(data) }),
  updatePaciente: (id, data) => apiRequest(`/pacientes/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deletePaciente: (id) => apiRequest(`/pacientes/${id}`, { method: 'DELETE' }),
  getDoctores: () => apiRequest('/doctores'),
  getDoctorById: (id) => apiRequest(`/doctores/${id}`),
  createDoctor: (data) => apiRequest('/doctores', { method: 'POST', body: JSON.stringify(data) }),
  updateDoctor: (id, data) => apiRequest(`/doctores/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteDoctor: (id) => apiRequest(`/doctores/${id}`, { method: 'DELETE' }),
  getCitas: () => apiRequest('/citas'),
  getCitaById: (id) => apiRequest(`/citas/${id}`),
  getCitasByPaciente: (paciente_id) => apiRequest(`/citas/paciente/${paciente_id}`),
  createCita: (data) => apiRequest('/citas', { method: 'POST', body: JSON.stringify(data) }),
  updateCitaEstado: (id, estado) => apiRequest(`/citas/${id}/estado`, { method: 'PUT', body: JSON.stringify({ estado }) }),
  deleteCita: (id) => apiRequest(`/citas/${id}`, { method: 'DELETE' }),
  getRecetasByCita: (cita_id) => apiRequest(`/recetas?cita_id=${cita_id}`),
  createReceta: (data) => apiRequest('/recetas', { method: 'POST', body: JSON.stringify(data) }),
  deleteReceta: (id) => apiRequest(`/recetas/${id}`, { method: 'DELETE' }),
  showNotification: (title, message) => {
    if (typeof Notification !== 'undefined') {
      new Notification(title || 'GESTOR DE CITAS', { body: message });
    }
  }
});
