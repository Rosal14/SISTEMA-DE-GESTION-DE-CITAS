const { app, BrowserWindow } = require('electron');
const path = require('node:path');
const { spawn } = require("child_process");
if (require('electron-squirrel-startup')) {
  app.quit();
}
let backendProcess;
const createWindow = () => {
  const mainWindow = new BrowserWindow({
    width: 1200,
    height: 900,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
    },
  });
  mainWindow.loadFile(path.join(__dirname, 'index.html'));
  mainWindow.webContents.openDevTools();
  if (!backendProcess) {
    backendProcess = spawn('node', ['server.js'],
      {
        cwd: path.join(__dirname, '../../backend'),
        stdio: 'pipe'
      }
    )
  };
  backendProcess.stdout.on('data', (data) => console.log(`Backend:${data}`));
};
app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
